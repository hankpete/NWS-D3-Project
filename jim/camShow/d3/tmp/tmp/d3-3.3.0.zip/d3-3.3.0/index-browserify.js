require("./d3");
module.exports = d3;
(function () { delete this.d3; })(); // unset global

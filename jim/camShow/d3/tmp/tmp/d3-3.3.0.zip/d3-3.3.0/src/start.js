d3 = (function(){
  var d3 = {version: "3.3.0"}; // semver
